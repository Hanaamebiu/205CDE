import sqlite3
from sqlite3 import Error

conn = sqlite3.connect('user.db')
c = conn.cursor()

# c.execute('DROP TABLE CLIENTS')

c.execute('CREATE TABLE IF NOT EXISTS CLIENTS (id INTEGER PRIMARY KEY AUTOINCREMENT,firstName CHAR(32), lastName CHAR(32), email CHAR(32), passwordHash CHAR(32), createAt CHAR(32)) ')

conn.commit()
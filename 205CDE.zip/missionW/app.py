from flask import Flask, render_template, Response, g, request
import sqlite3
from datetime import datetime

app = Flask(__name__, template_folder='frontend')

valueList = {}

conn = sqlite3.connect('./user.db', check_same_thread=False)
c = conn.cursor()

# Home page
@app.route("/")
def index():
    if 'name' not in valueList:
        valueList['name'] = "Login"
    return render_template('index.html', user=valueList['name'])

# Login page
@app.route("/login", methods=['GET', 'POST'])
def login():
    default_name = ''
    email = request.form.get('email', default_name)
    password = request.form.get('password', default_name)
    if email != '' and password != '':
        sql = '''SELECT firstName, lastName FROM CLIENTS WHERE email=? AND passwordHash = ?'''
        task = (email, password)
        c.execute(sql, task)
        records = c.fetchall()
        if len(records) > 0:
            firstName = records[0][0]
            conn.commit()
            valueList['name'] = firstName
            return render_template('index.html', user=valueList['name'])
    return render_template('login.html', user=valueList['name'])

# Contact page
@app.route("/contact")
def contact():
    return render_template('contact.html', user=valueList['name'])

# User page
@app.route("/user")
def user():
    sql ='''SELECT * FROM CLIENTS'''
    c.execute(sql)
    records = c.fetchall()
    recordList = []
    
    for row in records:
        currList = []
        for i in row:
            currList.append(i)
        recordList.append(currList)
    return render_template('user.html', user='testing', data=recordList)

# Sign up page
@app.route("/register", methods=['GET', 'POST'])
def register():
    default_name = ''
    email = request.form.get('email', default_name)
    password = request.form.get('password', default_name)
    firstName = request.form.get('firstName', default_name)
    lastName = request.form.get('lastName', default_name)
    if firstName != '' and lastName != '' and email != '' and password != '':
        now = datetime.now().strftime("%I:%M%p on %B %d, %Y")
        sql = '''INSERT INTO CLIENTS (firstName,lastName,email,passwordHash,createAt) VALUES (?,?,?,?,?);'''
        task = (firstName, lastName, email, password, now)
        c.execute(sql, task)
        print(task)
        conn.commit()
        valueList['name'] = firstName
        return render_template('index.html', user=valueList['name'])
    return render_template('register.html')

if __name__ == "__main__":
    app.run(debug=True, port=5000, host='0.0.0.0')